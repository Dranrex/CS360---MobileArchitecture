package com.example.projecttwo;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.List;
import java.util.Locale;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private List<InventoryItem> dataList;
    private AppDatabase db;

    public DataAdapter(List<InventoryItem> dataList) {
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itemdata, parent, false);
        db = Room.databaseBuilder(parent.getContext(), AppDatabase.class, "my-database").allowMainThreadQueries().build();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem data = dataList.get(position);
        holder.dataTextView.setText(String.format(Locale.getDefault(), "%s: %d", data.itemName, data.quantity));

        // Log the id for debugging
        Log.d("DataAdapter", "Item ID: " + data.getId());

        holder.increaseButton.setOnClickListener(v -> {
            data.quantity++;
            db.inventoryItemDAO().updateItem(data);
            notifyItemChanged(position);
        });
        holder.decreaseButton.setOnClickListener(v -> {
            data.quantity--;
            db.inventoryItemDAO().updateItem(data);
            notifyItemChanged(position);
            if (data.quantity == 0) {
                // Send SMS notification if quantity is zero
                sendSMSNotification();
            }
        });
        holder.deleteButton.setOnClickListener(v -> {
            int currentPosition = holder.getAdapterPosition();
            if (currentPosition != RecyclerView.NO_POSITION) {
                db.inventoryItemDAO().deleteItem(data);
                dataList.remove(currentPosition);
                notifyItemRemoved(currentPosition);
                notifyItemRangeChanged(currentPosition, dataList.size());
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void updateData(List<InventoryItem> newDataList) {
        this.dataList = newDataList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView dataTextView;
        public Button increaseButton, decreaseButton, deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            dataTextView = itemView.findViewById(R.id.dataTextView);
            increaseButton = itemView.findViewById(R.id.increaseButton);
            decreaseButton = itemView.findViewById(R.id.decreaseButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    private void sendSMSNotification() {
        // Logic to send SMS
    }
}
