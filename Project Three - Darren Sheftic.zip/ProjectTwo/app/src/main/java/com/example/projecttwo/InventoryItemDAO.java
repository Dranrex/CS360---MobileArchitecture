package com.example.projecttwo;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InventoryItemDAO {
    // Method to insert a new item
    @Insert
    void insertItem(InventoryItem item);

    // Method to delete an item
    @Delete
    void deleteItem(InventoryItem item);

    // Method to update existing item
    @Update
    void updateItem(InventoryItem item);

    // Method to get all inventory items
    @Query("SELECT * FROM inventory_items")
    List<InventoryItem> getAllItems();
}
