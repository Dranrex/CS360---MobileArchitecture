package com.example.projecttwo;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {User.class, InventoryItem.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    // Abstract methods to get the DAOs
    public abstract UserDAO userDAO();
    public abstract InventoryItemDAO inventoryItemDAO();
}
