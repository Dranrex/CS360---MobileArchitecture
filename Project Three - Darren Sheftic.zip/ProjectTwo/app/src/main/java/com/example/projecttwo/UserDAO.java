package com.example.projecttwo;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDAO {
    // Method to check user credentials during login
    @Query("SELECT * FROM users WHERE username = :username AND password = :password")
    User login(String username, String password);

    // Method to insert a new user into the database
    @Insert
    void insertUser(User user);
}
