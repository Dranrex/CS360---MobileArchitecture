package com.example.projecttwo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import android.Manifest;
import android.content.pm.PackageManager;

import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 1;
    private AppDatabase db;
    private DataAdapter adapter;
    private EditText editTextItemName, editTextItemQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datadisplay);

        db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "my-database").allowMainThreadQueries().build();

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<InventoryItem> itemList = db.inventoryItemDAO().getAllItems();
        adapter = new DataAdapter(itemList);
        recyclerView.setAdapter(adapter);

        editTextItemName = findViewById(R.id.editTextItemName);
        editTextItemQuantity = findViewById(R.id.editTextItemQuantity);
        Button buttonAddItem = findViewById(R.id.buttonAddItem);

        buttonAddItem.setOnClickListener(v -> {
            String itemName = editTextItemName.getText().toString();
            int quantity = Integer.parseInt(editTextItemQuantity.getText().toString());
            InventoryItem newItem = new InventoryItem();
            newItem.itemName = itemName;
            newItem.quantity = quantity;
            db.inventoryItemDAO().insertItem(newItem);
            adapter.updateData(db.inventoryItemDAO().getAllItems());
            requestSmsPermission();
        });
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            sendSMSNotification();
        }
    }

    private void sendSMSNotification() {
        // Logic to send SMS
        Toast.makeText(this, "SMS notification sent", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSMSNotification();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
